import ProductList from "../components/ProductList";

const Dashboard = () =>{
    return <ProductList></ProductList>
}

export default Dashboard;